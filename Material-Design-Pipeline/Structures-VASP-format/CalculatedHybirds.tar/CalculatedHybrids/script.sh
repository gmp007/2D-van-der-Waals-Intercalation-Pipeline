#!/bin/bash

# Get the current directory
current_dir=$(pwd)

# Go to the directory ../../Code_1/THN/
#cd ../../Code_1/THN || exit

# Loop through directories ending with _0
for dir in ../../../top_100_uncertain_ver4/*_0; do
    if [ -d "$dir" ]; then
        # Get the base name of the directory
        base_name=$(basename "$dir")
        echo "$base_name"
        # Check if POSCAR and CONTCAR files exist in the directory
        if [ -f "${dir}/POSCAR" ]; then
            cp "${dir}/POSCAR" ./${base_name}_POSCAR.vasp
        #    echo "POSCAR found"
        else
            echo "POSCAR not found in $dir"
        fi

        if [ -f "${dir}/CONTCAR" ]; then
	    echo "CONTCAR found"
            cp "${dir}/CONTCAR" ./${base_name}_CONTCAR.vasp
        else
            echo "CONTCAR not found in $dir"
        fi
    fi
done

